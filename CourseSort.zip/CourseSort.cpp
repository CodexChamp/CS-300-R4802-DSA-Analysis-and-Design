
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <unordered_map>
#include <algorithm> 

using namespace std;

//constructor for the course nodes
struct Course {
    string courseId;
    string courseTitle;
    vector<string> prerequisites; // List of prerequisite course numbers
};

// Im using a class because its best practice. i dont think its necassary for the project but it allows for reusablity 
class CourseManager {
private:
    unordered_map<string, Course> courseMap;

public:
    void displayMenu();
    void loadCourseDataFromFile(const string& filePath);
    void printAlphanumericCourseList();
    void printCourseInformation(const string& courseNumber);

private:
    void addCourse(const Course& course);
};

//file for reading data from file
void CourseManager::loadCourseDataFromFile(const string& filePath) {
    ifstream inFile(filePath);

    if (!inFile.is_open()) {
        cerr << "Error: could not open file from file path " << filePath << endl;
        return;
    }

    string line;
    while (getline(inFile, line)) { 
        //I had an issue where it wasnt showing anything when i wanted to print the courses so i added cout statements
        // when it was reading from the file so i knew it was reading it. 
        //cout << "Reading line: " << line << endl; // Debug 

        stringstream ss(line);
        string courseId, courseTitle, prerequisites;

        getline(ss, courseId, ',');
        getline(ss, courseTitle, ',');

        //cout << "Course ID: " << courseId << ", Title: " << courseTitle << endl; // Debug 

        Course course;
        course.courseId = courseId;
        course.courseTitle = courseTitle;

        
        while (getline(ss, prerequisites, ',')) {
            if (!prerequisites.empty()) {
                //cout << "Found prerequisite: " << prerequisites << endl; // Debug 
                course.prerequisites.push_back(prerequisites);
            }
        }

        addCourse(course);
        //cout << "Course added: " << course.courseId << endl; // Debug 
    }

    inFile.close();
}


//This function takes the courseId and adds them to the hash table
//this is for reading from the data structure and fnding the nodes through the ID number
void CourseManager::addCourse(const Course& course) {
    courseMap[course.courseId] = course;
}


void CourseManager::printAlphanumericCourseList() {
    vector<Course> sortedCourses;

    for (const auto& entry : courseMap) {
        sortedCourses.push_back(entry.second);
    }

    sort(sortedCourses.begin(), sortedCourses.end(),
        [](const Course& a, const Course& b) {
            return a.courseId < b.courseId;
        });

    
    for (const auto& course : sortedCourses) {
        cout << course.courseId << ": " << course.courseTitle << "\n";
    }
}

//Function to find all information about a class through its course ID
void CourseManager::printCourseInformation(const std::string& courseId) {
    if (courseMap.find(courseId) != courseMap.end()) {
        const Course& course = courseMap[courseId];
        cout << "Course ID: " << course.courseId << endl;
        cout << "Title: " << course.courseTitle <<endl;

        if (!course.prerequisites.empty()) {
            std::cout << "Prerequisites:" << std::endl;
            for (const auto& prerequisite : course.prerequisites) {
                std::cout << "- " << prerequisite << std::endl;
            }
        }
    }
    else {
        std::cout << "Course not found." << std::endl;
    }
}


// Display menu 
void CourseManager::displayMenu() {
    cout << "\nMenu:\n";
    cout << "1. Load Class List\n";
    cout << "2. Print Courses List\n";
    cout << "3. Print Course\n";
    cout << "4. Exit\n";
}

int main() {
    CourseManager manager;
    string filePath = "C:/Users/rylan/Downloads/snhu/C ++/CourseSort/CourseSort/Project_courses.txt";
   
    int choice;
    // i made it a case switch because it keeps from having toman if else trees.
    do {
        manager.displayMenu();
        cout << "Enter your choice: ";
        cin >> choice;
        cin.ignore(100, '\n');

        switch (choice) {
        case 1: {
            manager.loadCourseDataFromFile(filePath);
            break;
        }
        case 2: {
            cout << "\nAlphanumeric Course List:\n";
            manager.printAlphanumericCourseList();
            break;
        }
        case 3: {
            string courseNumber;
            cout << "Enter course number: ";
            cin >> courseNumber;
            manager.printCourseInformation(courseNumber);
            break;
        }
        case 4: {
            cout << "Exiting program. Goodbye!\n";
            break;
        }
        default: {
            cout << "Invalid choice. Please try again.\n";
        }
        }
    } while (choice != 4);

    return 0;
}